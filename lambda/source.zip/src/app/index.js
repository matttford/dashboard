import { getRandomMeme } from "./handlers/getRandomMeme.js";
const GetRandomMeme = "GetRandomMeme";
const typeRoutes = {
    [GetRandomMeme]: getRandomMeme,
};
export const typeRouter = async (request) => {
    const handler = typeRoutes[request.type];
    if (!handler) {
        throw new Error(`Unknown request type: ${request.type}`);
    }
    return await handler();
};
//# sourceMappingURL=index.js.map